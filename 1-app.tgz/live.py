import threading,queue,os,time
from playwright.sync_api import sync_playwright
BASE='https://www.doresh-tzion.co.il'; D=os.path.dirname(os.path.abspath(__file__))
class Live(threading.Thread):
    def __init__(s,sid):
        super().__init__(daemon=True); s.sid=sid; s.frame=None; s.fid=0; s.log=[]; s.cur_url=''; s.q=queue.Queue(); s.status={'status':'idle'}; s.start()
    def push(s,order,final=False): s.q.put(('sync',dict(order),final))
    def close(s): s.q.put(('close',None,False))
    def act(s,text):
        s.log.append(text); s.log=s.log[-8:]
    def cursor(s,loc):
        try:
            loc.scroll_into_view_if_needed(timeout=3000)
            b=loc.bounding_box()
            if b: s.pg.evaluate("""([x,y])=>{let c=document.getElementById('__cur');if(!c){c=document.createElement('div');c.id='__cur';c.style.cssText='position:fixed;z-index:2147483647;width:26px;height:26px;border-radius:50%;border:3px solid #e11;background:rgba(255,0,0,.25);pointer-events:none;transition:all .45s ease;left:0;top:0';document.body.appendChild(c)}c.style.left=(x-13)+'px';c.style.top=(y-13)+'px'}""",[b['x']+b['width']/2,b['y']+b['height']/2])
            s.w(600)
            try: loc.evaluate("e=>{e.style.outline='3px solid #e11'}")
            except Exception: pass
        except Exception: pass
    def click(s,loc,text):
        s.act(text); s.cursor(loc); loc.click(); s.w(300)
    def fillf(s,sel,val,text):
        s.act(text); loc=s.pg.locator(sel).first; s.cursor(loc); s.pg.fill(sel,val); s.w(500)
    def on_frame(s,params):
        import base64
        s.frame=base64.b64decode(params['data']); s.fid+=1
        try: s.cdp.send('Page.screencastFrameAck',{'sessionId':params['sessionId']})
        except Exception: pass
    def snap(s):
        try:
            s.pg.evaluate("document.querySelectorAll('.ann-card').forEach(e=>e.remove())"); s.cur_url=s.pg.url
        except Exception: pass
    def w(s,ms):
        for _ in range(max(1,ms//300)): s.pg.wait_for_timeout(300); s.snap()
    def run(s):
        with sync_playwright() as p:
            b=p.chromium.launch(args=['--disable-dev-shm-usage','--disable-gpu','--no-zygote']); ctx=b.new_context(locale='he-IL',viewport={'width':1100,'height':780}); s.pg=ctx.new_page()
            s.cdp=ctx.new_cdp_session(s.pg); s.cdp.on('Page.screencastFrame',s.on_frame); s.cdp.send('Page.startScreencast',{'format':'jpeg','quality':60,'everyNthFrame':2})
            s.items=[]; s.dirty=False; s.filled={}; s.pg.set_default_timeout(60000); s.pg.set_default_navigation_timeout(60000)
            try: s.pg.goto(BASE+'/books',wait_until='domcontentloaded'); s.w(1500)
            except Exception: pass
            while True:
                if s.q.empty(): s.pg.wait_for_timeout(250); s.snap(); continue
                k,o,final=s.q.get()
                if k=='close': break
                # coalesce: only the latest sync matters (keep final flag)
                while not s.q.empty():
                    k2,o2,f2=s.q.get()
                    if k2=='close': return s._cleanup(ctx,b)
                    o=o2; final=final or f2
                for attempt in range(3):
                    try: s.sync(o,final); break
                    except Exception as e:
                        s.status={'status':'error','error':str(e)[:200]}; s.snap()
                        s.dirty=True; s.filled={}
            s._cleanup(ctx,b)
    def _cleanup(s,ctx,b):
        try:
            s.pg.goto(BASE+'/checkout',wait_until='domcontentloaded'); s.pg.wait_for_timeout(2500)
            for _ in range(12):
                r=s.pg.query_selector('.checkout-summary-item-remove')
                if not r: break
                r.click(); s.pg.wait_for_timeout(900)
        except Exception: pass
        ctx.close(); b.close()
    def sync(s,o,final):
        pg=s.pg; sig=[(int(i['id']),int(i['qty'])) for i in o.get('items',[])]
        if sig!=s.items or s.dirty:
            s.status={'status':'running','log':'cart'}
            if s.items and not s.dirty and sig[:len(s.items)]==s.items: add=sig[len(s.items):]
            else:
                if s.items or s.dirty:
                    pg.goto(BASE+'/checkout',wait_until='domcontentloaded'); s.w(2000)
                    for _ in range(12):
                        r=pg.query_selector('.checkout-summary-item-remove')
                        if not r: break
                        r.click(); s.w(900)
                add=sig
            exp=sum(int(i['price'])*int(i['qty']) for i in o.get('items',[]))
            def do_add(lst):
                for id,q in lst:
                    s.act(f'פותח עמוד ספר {id}'); pg.goto(f'{BASE}/book/{id}',wait_until='domcontentloaded'); pg.wait_for_selector('.add-to-cart-btn',timeout=30000)
                    try: pg.wait_for_function("window.Blazor!==undefined",timeout=15000)
                    except Exception: pass
                    s.w(1800)
                    for _ in range(q-1): s.click(pg.locator('.qty-btn:has-text("+")').first,'מגדיל כמות'); s.w(300)
                    s.snap(); s.click(pg.locator('.add-to-cart-btn'),'מוסיף לסל'); s.w(2000)
            def cart_total():
                s.act('עובר לסל הקניות'); pg.goto(BASE+'/cart',wait_until='domcontentloaded'); s.w(2500)
                import re
                m=re.findall(r'סה"כ\s*([\d,]+)\s*₪',pg.inner_text('body')); return int(m[-1].replace(',','')) if m else 0
            do_add(add); tot=cart_total() if sig else 0; print('CART',tot,exp,flush=True)
            for _ in range(2):
                if tot==exp: break
                pg.goto(BASE+'/checkout',wait_until='domcontentloaded'); s.w(2000)
                for _ in range(15):
                    r=pg.query_selector('.checkout-summary-item-remove')
                    if not r: break
                    r.click(); s.w(900)
                do_add(sig); tot=cart_total()
            s.items=sig; s.filled={}; s.dirty=False
        has=any(o.get(k) for k in('first_name','phone','delivery'))
        if (has or final) and s.items:
            if '/checkout' not in pg.url or not s.filled.get('_on'):
                s.act('עובר לעמוד התשלום'); pg.goto(BASE+'/checkout',wait_until='domcontentloaded'); pg.wait_for_selector('input[name="_form.FirstName"]',timeout=20000); s.w(1200); s.filled={'_on':1}
            F=s.filled
            if o.get('delivery') and F.get('delivery')!=o['delivery']:
                s.click(pg.locator('.shipping-tile').nth(1 if o['delivery']=='home' else 0),'בוחר '+('משלוח עד הבית' if o['delivery']=='home' else 'איסוף עצמי')); F['delivery']=o['delivery']; s.w(700)
            for key,name in (('first_name','FirstName'),('last_name','LastName'),('phone','Phone')):
                v=o.get(key)
                if v and F.get(key)!=v: s.fillf(f'input[name="_form.{name}"]',v,{'first_name':'ממלא שם פרטי','last_name':'ממלא שם משפחה','phone':'ממלא טלפון'}[key]); F[key]=v
            if F.get('email')!='x': s.fillf('input[name="_form.Email"]','demo@example.com','ממלא מייל (דמו)'); F['email']='x'
            if o.get('delivery')=='home':
                for key,sel in (('city','#checkout-city'),('street','#checkout-street')):
                    v=o.get(key)
                    if v and F.get(key)!=v:
                        s.act('ממלא '+('עיר' if key=='city' else 'רחוב')); s.cursor(pg.locator(sel).first); pg.fill(sel,v); s.w(1600); opt=pg.locator(sel+'-list [role="option"]').first
                        if opt.count(): opt.click()
                        F[key]=v; s.w(600)
                v=o.get('house')
                if v and F.get('house')!=str(v): s.fillf('input[name="_form.StreetNumber"]',str(v),'ממלא מספר בית'); F['house']=str(v)
            if final:
                s.fillf('textarea[name="_form.CustomerNote"]','הזמנת דמו - לא לטפל, לא לשלם','ממלא הערה (דמו)')
                btn=pg.get_by_text('מעבר לתשלום מאובטח').first; s.act('עוצר לפני התשלום - לא לוחץ'); s.cursor(btn); s.w(1500)
                pg.screenshot(path=f"{D}/live/{s.sid}_ready.png",full_page=True)
                s.status={'status':'done','log':'ready'}; return
        s.status={'status':'running' if not final else 'running','log':'synced'}
