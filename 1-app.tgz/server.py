import time,glob,os,json,uuid,threading,subprocess,hashlib,asyncio,glob
from flask import Flask,request,jsonify,send_file,send_from_directory
import brain,order_bot,edge_tts,live
try:
    import llm
except Exception as e: llm=None; print('no llm',e)
app=Flask(__name__); SES={}; LV={}; LOCK=threading.Lock(); D=os.path.dirname(os.path.abspath(__file__))
VOICE='he-IL-AvriNeural'
def run_order(sid):
    S=SES[sid]; o=dict(S['order']); o.update(email='demo@example.com',note='הזמנת דמו - לא לטפל, לא לשלם')
    o['items']=[dict(id=i['id'],qty=i['qty']) for i in o['items']]
    out=f"{D}/runs/{sid}"; S['run']={'status':'running'}
    with LOCK:
        r=order_bot.run(o,out,log=lambda m:S['run'].update(log=m))
    if r.get('video'):
        subprocess.run(['ffmpeg','-y','-i',r['video'],'-c:v','libx264','-pix_fmt','yuv420p',f'{out}/run.mp4'],capture_output=True)
    S['run']={'status':'done' if r['ok'] else 'error','error':r.get('error'),'shots':[f for f in('1_cart.png','2_form.png','3_ready_to_pay.png') if os.path.exists(f'{out}/{f}')],'video':os.path.exists(f'{out}/run.mp4'),'summary':r.get('summary','')}
    S['stage']='done'
import requests as _rq
OAI=os.environ.get('OPENAI_API_KEY') or (open(glob.glob(os.path.expanduser('~/.vault/openai-api-key-doresh-tzion-voice-demo-*/password'))[0]).read().strip() if glob.glob(os.path.expanduser('~/.vault/openai-api-key-doresh-tzion-voice-demo-*/password')) else '')
RT_MODEL=os.environ.get('RTM','gpt-realtime-2.1')
CATTXT='\n'.join(f"{c['id']}: {c['name']} - {c['price']} ש\"ח"+('' if c['in_stock'] else ' (חסר במלאי)') for c in brain.CAT)
RT_INSTR=f'''אתה נציג קולי של אתר "דורש ציון" (ספרי הרב בן ציון מוצפי) לקבלת הזמנות ספרים בשיחה. דבר רק בעברית, בקול רגוע, מכבד וברור, בקצב נעים ובמשפטים קצרים (משפט אחד עד שניים). הקהל חרדי - שפה מכובדת, בלי סלנג.
קטלוג (id: שם - מחיר):
{CATTXT}
משלוח עד הבית 40 ש"ח; איסוף עצמי מהמחסן ברמות ירושלים (יעקב אלעזר 8) בחינם.
הזרימה: איזה ספר ובאיזו כמות (אם יש כמה ספרים דומים שאל איזה; ספר חסר במלאי - הצע אחר), עוד ספר?, משלוח או איסוף, שם פרטי ומשפחה, טלפון, ולמשלוח גם עיר, רחוב ומספר בית. 
בכל פעם שמתקבל או משתנה פרט בהזמנה קרא לפונקציה update_order עם כל מצב ההזמנה המצטבר. אחרי שהכל מלא - הקרא ללקוח סיכום קצר עם הסכום הכולל מתוך מה שהפונקציה החזירה (אל תחשב בעצמך) ושאל אם לאשר. רק אחרי "כן" מפורש קרא ל-confirm_order, ואז אמור שאתה ממלא את ההזמנה באתר ועוצר לפני התשלום - לא נשלחת הזמנה ולא מתבצע תשלום. אל תמציא ספרים או מחירים. התחל בברכה קצרה ושאלה איזה ספר רוצים להזמין.'''
RT_TOOLS=[{"type":"function","name":"update_order","description":"עדכון מצב ההזמנה המצטבר. שלח את כל הפריטים והפרטים הידועים עד כה.","parameters":{"type":"object","properties":{"items":{"type":"array","items":{"type":"object","properties":{"id":{"type":"integer"},"qty":{"type":"integer"}},"required":["id","qty"]}},"delivery":{"type":"string","enum":["home","pickup"]},"first_name":{"type":"string"},"last_name":{"type":"string"},"phone":{"type":"string","description":"ספרות בלבד"},"city":{"type":"string"},"street":{"type":"string"},"house":{"type":"string"}},"required":["items"]}},{"type":"function","name":"confirm_order","description":"לקרוא רק אחרי שהלקוח אישר במפורש את סיכום ההזמנה.","parameters":{"type":"object","properties":{}}}]
@app.route('/api/rt/offer',methods=['POST'])
def rt_offer():
    sdp=request.get_data(as_text=True)
    sess={"type":"realtime","model":RT_MODEL,"instructions":RT_INSTR,"output_modalities":["audio"],"tools":RT_TOOLS,"tool_choice":"auto",
          "audio":{"input":{"transcription":{"model":"gpt-4o-transcribe","language":"he"},"noise_reduction":{"type":"near_field"},"turn_detection":{"type":"server_vad","silence_duration_ms":600}},"output":{"voice":"marin"}}}
    r=_rq.post('https://api.openai.com/v1/realtime/calls',headers={'Authorization':'Bearer '+OAI},files={'sdp':(None,sdp),'session':(None,json.dumps(sess))},timeout=30)
    if r.status_code>=300: print('rt err',r.status_code,r.text[:400],flush=True); return (r.text,r.status_code)
    return (r.text,200,{'Content-Type':'application/sdp'})
@app.route('/api/rt/tool',methods=['POST'])
def rt_tool():
    d=request.json; S=SES.get(d['sid']) or SES.setdefault(d['sid'],brain.new_session()); o=S['order']; a=d.get('args') or {}
    if d['name']=='update_order':
        byid={str(c['id']):c for c in brain.CAT}; items=[]
        for i in a.get('items') or []:
            c=byid.get(str(i.get('id')))
            if c and c['in_stock'] and int(i.get('qty',0))>0: items.append(dict(id=int(c['id']),name=c['name'],price=c['price'],qty=int(i['qty'])))
        o['items']=items
        if a.get('delivery') in('home','pickup'): o['delivery']=a['delivery']
        for k in('first_name','last_name','phone','city','street','house'):
            if a.get(k): o[k]=str(a[k])
        if o.get('phone'): o['phone']=''.join(ch for ch in o['phone'] if ch.isdigit())
        if d['sid'] in LV: LV[d['sid']].push(o)
        s,sh=brain.total(o); miss=[k for k in(['first_name','phone'] + (['city','street','house'] if o.get('delivery')=='home' else [])) if not o.get(k)]
        if not o.get('delivery'): miss.append('delivery')
        if not items: miss.append('items')
        return jsonify(items=[f"{i['qty']} x {i['name']} ({i['price']} ש\"ח ליחידה)" for i in items],subtotal=s,shipping=sh,total=s+sh,missing=miss)
    if d['name']=='confirm_order':
        miss=[k for k in(['first_name','phone'] + (['city','street','house'] if o.get('delivery')=='home' else [])) if not o.get(k)]
        if not o.get('items') or not o.get('delivery') or miss: return jsonify(ok=False,missing=miss+([] if o.get('items') else ['items'])+([] if o.get('delivery') else ['delivery']))
        o.setdefault('last_name','דמו'); S['stage']='running'; S['run']={'status':'running'}
        if d['sid'] in LV: LV[d['sid']].push(o,final=True)
        return jsonify(ok=True,note='ההזמנה מתמלאת באתר ועוצרת לפני תשלום')
@app.route('/rt')
def rtpage(): return send_from_directory(D,'rt.html')
@app.route('/')
def idx(): return send_from_directory(D,'index.html')
@app.route('/api/start',methods=['POST'])
def start():
    [x.close() for x in list(LV.values())]; LV.clear(); sid=uuid.uuid4().hex[:8]; SES[sid]=brain.new_session(); LV[sid]=live.Live(sid); return jsonify(sid=sid,reply=brain.GREET)
@app.route('/api/say',methods=['POST'])
def say():
    d=request.json; S=SES.get(d['sid']) or SES.setdefault(d['sid'],brain.new_session())
    r=None
    if llm and S.get('mode')!='rules' and os.environ.get('RULES')!='1':
        try: r=llm.step(S,d['text']); S['mode']='llm'
        except Exception as e:
            print('llm fail',e,flush=True); S['mode']='rules'
            o=S['order']; S['stage']='book' if not o['items'] else ('delivery' if not o.get('delivery') else 'name')
    if r is None: r=brain.step(S,d['text'])
    go=S.pop('go',False)
    if d['sid'] in LV:
        LV[d['sid']].push(S['order'],final=go)
        if go: S['run']={'status':'running'}
    s,sh=brain.total(S['order'])
    return jsonify(reply=r,order=S['order'],stage=S['stage'],total=s+sh,ship=sh)
@app.route('/api/status/<sid>')
def status(sid):
    S=SES.get(sid,{}); L=LV.get(sid); run=S.get('run')
    if L and run and L.status.get('status')=='done':
        run={'status':'done','shots':[]}
        if not getattr(L,'closing',False): L.closing=True; threading.Timer(25,L.close).start()
    elif L and run and L.status.get('status')=='error': run={'status':'error','error':L.status.get('error')}
    return jsonify(run=run,stage=S.get('stage'))
@app.route('/api/stream/<sid>')
def stream(sid):
    L=LV.get(sid)
    def gen():
        last=-1; n=0
        while True:
            L2=LV.get(sid)
            if L2 and L2.frame and (L2.fid!=last or n%6==0):
                last=L2.fid; fr=L2.frame
                yield b'--f\r\nContent-Type: image/jpeg\r\nContent-Length: '+str(len(fr)).encode()+b'\r\n\r\n'+fr+b'\r\n'
            n+=1; time.sleep(0.1)
    r=app.response_class(gen(),mimetype='multipart/x-mixed-replace; boundary=f'); r.headers['Cache-Control']='no-store'; r.headers['X-Accel-Buffering']='no'; return r
@app.route('/api/livelog/<sid>')
def livelog(sid):
    L=LV.get(sid); return jsonify(url=getattr(L,'cur_url','') if L else '',log=list(getattr(L,'log',[])) if L else [])
@app.route('/api/live/<sid>')
def livejpg(sid):
    f=f'{D}/live/{sid}.jpg'
    if not os.path.exists(f): return ('',404)
    r=send_file(f,mimetype='image/jpeg'); r.headers['Cache-Control']='no-store'; return r
@app.route('/api/tts')
def tts():
    t=request.args['text']; f=f"{D}/tts/{hashlib.md5(t.encode()).hexdigest()}.mp3"
    if not os.path.exists(f): tmp=f+'.%s'%uuid.uuid4().hex[:6]; asyncio.run(edge_tts.Communicate(t,VOICE,rate='+20%').save(tmp)); os.replace(tmp,f)
    return send_file(f,mimetype='audio/mpeg')
@app.route('/runs/<sid>/<fn>')
def runfile(sid,fn): return send_from_directory(f'{D}/runs/{sid}',fn)
import phone
phone.register(app,SES,LV,brain,live,RT_INSTR,RT_TOOLS)
if __name__=='__main__': app.run('0.0.0.0',int(os.environ.get('PORT',8099)),threaded=True)
