"""Fills the doresh-tzion.co.il checkout from an order JSON and STOPS before payment.
usage: python3 order_bot.py order.json outdir
order: {"items":[{"id":45,"qty":2}],"delivery":"home"|"pickup","first_name","last_name","phone","email","city","street","house","note"}"""
import json,sys,os,time
from playwright.sync_api import sync_playwright
BASE='https://www.doresh-tzion.co.il'
def run(order,out,headless=True,log=print):
    os.makedirs(out,exist_ok=True)
    with sync_playwright() as p:
        b=p.chromium.launch(headless=headless)
        ctx=b.new_context(locale='he-IL',viewport={'width':1280,'height':900},record_video_dir=out,record_video_size={'width':1280,'height':900})
        pg=ctx.new_page(); res={'ok':False}
        try:
            for it in order['items']:
                log(f"book {it['id']} x{it['qty']}")
                pg.goto(f"{BASE}/book/{it['id']}",wait_until='domcontentloaded'); pg.wait_for_selector('.add-to-cart-btn',timeout=20000); pg.wait_for_timeout(1500)
                for _ in range(it['qty']-1): pg.click('.qty-btn:has-text("+")'); pg.wait_for_timeout(200)
                pg.click('.add-to-cart-btn'); pg.wait_for_timeout(1800)
            pg.goto(f"{BASE}/cart",wait_until='domcontentloaded'); pg.wait_for_timeout(3500); pg.screenshot(path=f'{out}/1_cart.png')
            pg.get_by_text('המשך להזמנה').first.click(); pg.wait_for_selector('input[name="_form.FirstName"]',timeout=20000); pg.wait_for_timeout(1000)
            try: pg.click('button.btn-close, .popup-close, button:has-text("×")',timeout=1500)
            except Exception: pass
            pg.add_style_tag(content='[class*="popup"],[class*="promo"],[class*="floating"],[class*="toast"]{display:none!important}')
            def f(n,v): pg.fill(f'input[name="_form.{n}"]',v or ''); 
            f('FirstName',order['first_name']); f('LastName',order['last_name']); f('Phone',order['phone']); f('Email',order['email'])
            if order.get('delivery')=='home':
                pg.locator('.shipping-tile').nth(1).click(); pg.wait_for_timeout(1000)
                for sel,v in (('#checkout-city',order['city']),('#checkout-street',order['street'])):
                    pg.fill(sel,v); pg.wait_for_timeout(1800)
                    opt=pg.locator(sel+'-list [role="option"]').first
                    if opt.count(): opt.click()
                    pg.wait_for_timeout(700)
                f('StreetNumber',str(order['house']))
            if order.get('note'): pg.fill('textarea[name="_form.CustomerNote"]',order['note'])
            pg.wait_for_timeout(800)
            pg.evaluate("document.querySelectorAll('.ann-card').forEach(e=>e.remove())"); pg.evaluate("window.scrollTo(0,0)"); pg.screenshot(path=f'{out}/2_form.png')
            btn=pg.get_by_text('מעבר לתשלום מאובטח'); btn.scroll_into_view_if_needed(); pg.wait_for_timeout(800); pg.evaluate("document.querySelectorAll('.ann-card').forEach(e=>e.remove())")
            pg.screenshot(path=f'{out}/3_ready_to_pay.png',full_page=True)
            res['summary']=pg.inner_text('.checkout-summary, aside, main')[:1500] if pg.query_selector('.checkout-summary,aside,main') else ''
            res['ok']=True   # NOTE: intentionally never clicks the pay button
        except Exception as e:
            res['error']=str(e); pg.screenshot(path=f'{out}/error.png')
        finally:
            try: # empty the cart
                pg.goto(f"{BASE}/checkout",wait_until='domcontentloaded'); pg.wait_for_timeout(3000)
                for _ in range(10):
                    r=pg.query_selector('.checkout-summary-item-remove')
                    if not r: break
                    r.click(); pg.wait_for_timeout(1200)
            except Exception: pass
            v=pg.video.path() if pg.video else None
            ctx.close(); b.close()
            if v: res['video']=str(v)
    return res
if __name__=='__main__':
    print(json.dumps(run(json.load(open(sys.argv[1])),sys.argv[2]),ensure_ascii=False))
