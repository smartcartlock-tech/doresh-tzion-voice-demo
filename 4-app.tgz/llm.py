import time,json,os,urllib.request,glob
import brain
KEY=os.environ.get('GEMINI_API_KEY') or open(glob.glob(os.path.expanduser('~/.vault/gemini-api-key-doresh-tzion-voice-demo-*/password'))[0]).read().strip()
MODEL=os.environ.get('GM','gemini-3.5-flash')
CATTXT='\n'.join(f"{c['id']}: {c['name']} - {c['price']} ש\"ח"+('' if c['in_stock'] else ' (חסר במלאי)') for c in brain.CAT)
SYS=f"""אתה נציג קולי אדיב של אתר "דורש ציון" (ספרי הרב בן ציון מוצפי) לקבלת הזמנות ספרים בטלפון. הקהל חרדי: דבר עברית רגועה, מכובדת וברורה, משפט אחד קצר (עד 18 מילים; בסיכום ההזמנה עד 35 מילים) כי זה נאמר בקול ורוצים קצב מהיר. אל תשתמש באימוג'ים או סימנים מיוחדים.
קטלוג (id: שם - מחיר):
{CATTXT}
משלוח עד הבית 40 ש"ח, איסוף עצמי מהמחסן ברמות ירושלים (יעקב אלעזר 8) 0 ש"ח.
זרימה: לברר איזה ספר/ים ובאיזו כמות (אם יש כמה ספרים דומים - לשאול איזה; ספר חסר במלאי - להציע אחר), משלוח או איסוף, שם פרטי ומשפחה, טלפון, ולמשלוח גם עיר, רחוב ומספר בית. אז לסכם בקצרה עם סך הכל (סכום הספרים + משלוח) ולבקש אישור. רק אחרי שהלקוח אישר במפורש את הסיכום - confirmed=true. אל תמציא ספרים או מחירים שאינם בקטלוג. אם הלקוח שואל משהו לא קשור להזמנה, ענה בקצרה וחזור להזמנה. מספרי טלפון - ספרות בלבד.
החזר JSON בלבד: {{"reply": "מה שאומרים ללקוח", "items":[{{"id":מספר,"qty":מספר}}], "delivery":"home"|"pickup"|null, "first_name":null|"", "last_name":null|"", "phone":null|"", "city":null|"", "street":null|"", "house":null|"", "confirmed":false}}
השדות items וכו' מייצגים את כל מצב ההזמנה המצטבר עד כה (לא רק מה שנאמר עכשיו)."""
def step(S,text):
    h=S.setdefault('hist',[]); h.append({'role':'user','parts':[{'text':text}]})
    body={'systemInstruction':{'parts':[{'text':SYS}]},'contents':h,'generationConfig':{'responseMimeType':'application/json','temperature':0.3,'thinkingConfig':{'thinkingBudget':0}}}
    req=urllib.request.Request(f'https://generativelanguage.googleapis.com/v1beta/models/{MODEL}:generateContent',json.dumps(body).encode(),{'Content-Type':'application/json','x-goog-api-key':KEY})
    import concurrent.futures as cf
    def call(m):
        rq=urllib.request.Request(f'https://generativelanguage.googleapis.com/v1beta/models/{m}:generateContent',json.dumps(body).encode(),{'Content-Type':'application/json','x-goog-api-key':KEY})
        return json.load(urllib.request.urlopen(rq,timeout=14))
    r=None; err=None
    for rnd in range(4):
        ex=cf.ThreadPoolExecutor(8); fs=[ex.submit(call,m) for m in (MODEL,'gemini-3.8-flash','gemini-3.7-flash','gemini-3.6-flash','gemini-3.1-flash-lite','gemini-flash-latest')]
        try:
            for f in cf.as_completed(fs,timeout=14):
                try: r=f.result(); break
                except Exception as e: err=e
        except Exception as e: err=e
        ex.shutdown(wait=False)
        if r: break
        time.sleep(1)
    if not r: h.pop(); raise err or RuntimeError('llm failed')
    txt=''.join(p.get('text','') for p in r['candidates'][0]['content']['parts'] if 'text' in p)
    d=json.loads(txt); h.append({'role':'model','parts':[{'text':json.dumps(d,ensure_ascii=False)}]})
    o=S['order']; byid={str(c['id']):c for c in brain.CAT}
    items=[]
    for i in d.get('items') or []:
        c=byid.get(str(i.get('id')))
        if c and c['in_stock'] and int(i.get('qty',0))>0: items.append(dict(id=int(c['id']),name=c['name'],price=c['price'],qty=int(i['qty'])))
    o['items']=items
    if d.get('delivery') in('home','pickup'): o['delivery']=d['delivery']
    for k in('first_name','last_name','phone','city','street','house'):
        if d.get(k): o[k]=str(d[k])
    if o.get('phone'): o['phone']=''.join(ch for ch in o['phone'] if ch.isdigit())
    ready=items and o.get('delivery') and o.get('first_name') and o.get('phone') and (o['delivery']=='pickup' or all(o.get(k) for k in('city','street','house')))
    if d.get('confirmed') and ready: d['reply']='מעולה, תודה. אני ממלא עכשיו את ההזמנה באתר, ועוצר לפני שלב התשלום.'; S['stage']='running'; S['go']=True; o.setdefault('last_name','דמו')
    elif d.get('confirmed'): S['stage']='collect'
    else: S['stage']='collect'
    return d['reply']
