import re,json,os,urllib.request
CAT=[c for c in json.load(open(os.path.join(os.path.dirname(__file__),'catalog.json')))]
for c in CAT: c['name']=c['name'].strip()
SHIP=40
STOP=set('את של ספר ספרים אני רוצה רוצים להזמין בבקשה לי עוד גם כן אם יש לכם לקבל הזמנה אפשר רציתי מבקש מבקשת צריך צריכה הספר הזה'.split())
HEBNUM={'אחד':1,'אחת':1,'שניים':2,'שתיים':2,'שני':2,'שתי':2,'שלוש':3,'שלושה':3,'ארבע':4,'ארבעה':4,'חמש':5,'חמישה':5,'שש':6,'שישה':6,'שבע':7,'שבעה':7,'שמונה':8,'תשע':9,'תשעה':9,'עשר':10,'עשרה':10}
def norm(s): return re.sub(r'[\"\'״׳”“\-–,.!?]',' ',s).split()
def toks(s): return [t for t in norm(s) if t not in STOP]
def strip_prefix(t): return t[1:] if len(t)>3 and t[0] in 'הובלמש' else t
def find_books(text,only_stock=False):
    q=[strip_prefix(t) for t in toks(text) if not t.isdigit() and t not in HEBNUM]
    if not q: return []
    res=[]
    for c in CAT:
        nt=[strip_prefix(t) for t in norm(c['name'])]
        hit=sum(1 for t in q if t in nt or any(t in x or x in t for x in nt if len(t)>2))
        if hit==0: continue
        res.append((hit/len(q), hit/len(nt), c))
    res.sort(key=lambda x:(-x[0],-x[1]))
    if not res: return []
    best=res[0][0]
    if best<0.5: return []
    return [r[2] for r in res if r[0]==best]
def get_qty(text):
    m=re.search(r'\d+',text)
    if m: return int(m.group())
    for t in norm(text):
        if t in HEBNUM: return HEBNUM[t]
    return None
def yes(t): return any(w in norm(t) for w in ['כן','בסדר','אישור','מאשר','מאשרת','נכון','יאללה','סבבה','אוקיי','אוקי','בטח','אשר','כמובן','מצוין'])
def no(t): return any(w in norm(t) for w in ['לא','די','זהו','סיימתי','בלי','אין'])
def total(o):
    s=sum(i['qty']*i['price'] for i in o['items']); return s,(SHIP if o.get('delivery')=='home' else 0)
def fmt_items(o): return ', '.join(f"{i['qty']} × {i['name']}" for i in o['items'])
def new_session(): return dict(stage='book',order=dict(items=[],delivery=None),pending=None,cand=None,done=False,run=None)
GREET='שלום וברכה, הגעתם להזמנת ספרים של דורש ציון. איזה ספר תרצו להזמין?'
def step(S,text):
    o=S['order']; st=S['stage']; t=text.strip()
    if not t: return 'לא שמעתי, אפשר לחזור על זה?'
    if st in('book','pick'):
        if st=='pick' and S['cand']:
            n=get_qty(t); cand=S['cand']
            ch=None
            if n and 1<=n<=len(cand) and len(norm(t))<=2: ch=cand[n-1]
            else:
                f=[c for c in find_books(t) if c in cand]; ch=f[0] if len(f)==1 else None
            if not ch: return 'לא הבנתי איזה מהם. אפשר לומר את השם המלא של הספר?'
            found=[ch]
        else: found=find_books(t)
        if not found: return 'לא מצאתי ספר כזה בקטלוג. אפשר לומר את שם הספר, למשל סידור קול ציון ימי החול, או מחזור לראש השנה?'
        if len(found)>1:
            S['stage']='pick'; S['cand']=found[:4]
            lst=', '.join(f"{i+1}. {c['name']}" for i,c in enumerate(S['cand']))
            return f"מצאתי כמה אפשרויות: {lst}. איזה מהם?"
        b=found[0]
        if not b['in_stock']: S['stage']='book'; return f"הספר {b['name']} חסר כרגע במלאי. אפשר לבחור ספר אחר?"
        S['pending']=b; S['cand']=None
        n=get_qty(t) if st=='book' else None
        if n and n<50: return add_item(S,n)
        S['stage']='qty'; return f"{b['name']}, במחיר {b['price']} שקלים. כמה עותקים תרצו?"
    if st=='qty':
        n=get_qty(t)
        if not n: return 'כמה עותקים? אפשר לומר מספר.'
        return add_item(S,n)
    if st=='more':
        if no(t) and not find_books(t): S['stage']='delivery'; return 'מעולה. תרצו משלוח עד הבית, בעלות ארבעים שקלים, או איסוף עצמי ברמות בירושלים, בחינם?'
        if yes(t) and not find_books(t): S['stage']='book'; return 'איזה ספר להוסיף?'
        S['stage']='book'; return step(S,t)
    if st=='delivery':
        if any(w in t for w in ['בית','משלוח','שליח','הביתה']): o['delivery']='home'
        elif any(w in t for w in ['איסוף','לאסוף','אוסף','רמות','עצמי']): o['delivery']='pickup'
        else: return 'משלוח עד הבית או איסוף עצמי?'
        S['stage']='name'; return 'מה השם המלא שלכם?'
    if st=='name':
        w=norm(t); w=[x for x in w if x not in('השם','שלי','קוראים','לי','אני')]
        if not w: return 'מה השם המלא?'
        o['first_name']=w[0]; o['last_name']=' '.join(w[1:]) or 'דמו'
        S['stage']='phone'; return f"נעים להכיר, {o['first_name']}. מה מספר הטלפון שלכם?"
    if st=='phone':
        d=re.sub(r'\D','',t)
        if len(d)<9:
            m={'אפס':'0','אחד':'1','שתיים':'2','שניים':'2','שלוש':'3','ארבע':'4','חמש':'5','שש':'6','שבע':'7','שמונה':'8','תשע':'9'}
            d=''.join(m[x] if x in m else re.sub(r'\D','',x) for x in norm(t))
        if len(d)<9: return 'לא קלטתי את המספר. אפשר לומר אותו שוב ספרה אחרי ספרה, או להקליד בתיבה?'
        o['phone']=d
        if o['delivery']=='home': S['stage']='city'; return 'באיזו עיר המשלוח?'
        return summary(S)
    if st=='city': o['city']=t.replace('ב','',1) if t.startswith('בי') and False else t; S['stage']='street'; return 'באיזה רחוב?'
    if st=='street': o['street']=t; S['stage']='house'; return 'ומה מספר הבית?'
    if st=='house':
        n=get_qty(t)
        if not n: return 'מה מספר הבית?'
        o['house']=n; return summary(S)
    if st=='confirm':
        if yes(t) and not no(t):
            S['stage']='running'; S['go']=True
            return 'מעולה, ההזמנה בטיפול. אני ממלא עכשיו את ההזמנה באתר, ועוצר לפני התשלום.'
        if no(t): S['stage']='book'; o['items']=[]; return 'בסדר, נתחיל מחדש. איזה ספר תרצו?'
        return 'לאשר את ההזמנה? כן או לא.'
    return 'ההזמנה כבר בטיפול.'
def add_item(S,n):
    b=S['pending']; S['order']['items'].append(dict(id=int(b['id']),name=b['name'],price=b['price'],qty=n))
    S['stage']='more'; return f"הוספתי {n} × {b['name']}. תרצו להוסיף עוד ספר?"
def summary(S):
    o=S['order']; s,sh=total(o); S['stage']='confirm'
    adr=f" לכתובת {o['street']} {o['house']}, {o['city']}" if o['delivery']=='home' else ', איסוף עצמי ברמות'
    return f"סיכום ההזמנה: {fmt_items(o)}. משלוח {sh} שקלים{adr}. סך הכל {s+sh} שקלים. על שם {o['first_name']} {o['last_name'] if o['last_name']!='דמו' else ''}. לאשר?"
