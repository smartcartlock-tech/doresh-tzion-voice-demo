import os,json,threading,time,base64,audioop,uuid,requests
from flask import request,Response,jsonify
from flask_sock import Sock
import websocket
GEM_KEY=os.environ.get('GEMINI_API_KEY','')
GEM_MODEL=os.environ.get('GEMINI_LIVE_MODEL','gemini-3.1-flash-live-preview')
TW_SID=os.environ.get('TWILIO_ACCOUNT_SID',''); TW_TOK=os.environ.get('TWILIO_AUTH_TOKEN','')
TW_FROM=os.environ.get('TWILIO_FROM',''); CALL_TO=os.environ.get('CALL_TO','+972503500750'); CALL_KEY=os.environ.get('CALL_KEY','')
LATEST={'sid':None,'status':'idle','t':0}
def decls(tools):
    out=[]
    for t in tools: out.append({"name":t['name'],"description":t['description'],"parameters":t['parameters']})
    return out
def register(app,SES,LV,brain,live,instr,tools):
    sock=Sock(app)
    @app.route('/api/call',methods=['POST','GET'])
    def api_call():
        if not CALL_KEY or request.args.get('key')!=CALL_KEY: return ('forbidden',403)
        if not (TW_SID and TW_TOK and TW_FROM): return jsonify(error='twilio not configured'),500
        base=os.environ.get('PUBLIC_URL') or request.host_url.replace('http://','https://').rstrip('/')
        r=requests.post(f'https://api.twilio.com/2010-04-01/Accounts/{TW_SID}/Calls.json',auth=(TW_SID,TW_TOK),
            data={'To':CALL_TO,'From':TW_FROM,'Url':base+'/twilio/voice','Method':'POST'},timeout=20)
        return jsonify(status=r.status_code,body=r.json())
    @app.route('/twilio/voice',methods=['POST','GET'])
    def tw_voice():
        host=(os.environ.get('PUBLIC_URL') or request.host_url).replace('https://','').replace('http://','').rstrip('/')
        x=f'<?xml version="1.0" encoding="UTF-8"?><Response><Connect><Stream url="wss://{host}/twilio/ws"/></Connect></Response>'
        return Response(x,mimetype='text/xml')
    @app.route('/call')
    def callpage():
        from flask import send_from_directory
        return send_from_directory(os.path.dirname(os.path.abspath(__file__)),'call.html')

    @app.route('/voice')
    def voicepage():
        from flask import send_from_directory
        return send_from_directory(os.path.dirname(os.path.abspath(__file__)),'voice.html')
    @sock.route('/browser/ws')
    def br_ws(ws):
        sid=uuid.uuid4().hex[:8]; SES[sid]=brain.new_session()
        for x in list(LV.values()): x.close()
        LV.clear(); LV[sid]=live.Live(sid); LATEST.update(sid=sid,status='in-call',t=time.time())
        st={'stop':False}; lock=threading.Lock()
        g=websocket.create_connection('wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key='+GEM_KEY,timeout=30); g.settimeout(None)
        def bsend(x):
            with lock:
                try: ws.send(x)
                except Exception: st['stop']=True
        def gsend(o):
            try: g.send(json.dumps(o))
            except Exception: st['stop']=True
        gsend({'setup':{'model':'models/'+GEM_MODEL,'generationConfig':{'responseModalities':['AUDIO'],'speechConfig':{'voiceConfig':{'prebuiltVoiceConfig':{'voiceName':'Charon'}}}},
            'systemInstruction':{'parts':[{'text':instr+'\nהשיחה מתנהלת בדפדפן. התחל מיד בברכה קצרה.'}]},
            'tools':[{'functionDeclarations':decls(tools)}],'inputAudioTranscription':{},'outputAudioTranscription':{}}})
        g.recv()
        def rd():
            while not st['stop']:
                try: raw=g.recv()
                except Exception: break
                if not raw: break
                m=json.loads(raw); sc=m.get('serverContent') or {}
                if sc.get('interrupted'): bsend(json.dumps({'t':'interrupt'}))
                for p in (sc.get('modelTurn') or {}).get('parts',[]):
                    d=(p.get('inlineData') or {}).get('data')
                    if d: bsend(base64.b64decode(d))
                if sc.get('inputTranscription'): bsend(json.dumps({'t':'user','text':sc['inputTranscription'].get('text')}))
                if sc.get('outputTranscription'): bsend(json.dumps({'t':'bot','text':sc['outputTranscription'].get('text')}))
                tc=m.get('toolCall')
                if tc:
                    resp=[]
                    for fc in tc.get('functionCalls',[]):
                        with app.test_client() as c:
                            r=c.post('/api/rt/tool',json={'sid':sid,'name':fc['name'],'args':fc.get('args') or {}}).get_json()
                        resp.append({'id':fc['id'],'name':fc['name'],'response':r})
                    gsend({'toolResponse':{'functionResponses':resp}})
            st['stop']=True
        threading.Thread(target=rd,daemon=True).start()
        bsend(json.dumps({'t':'sid','sid':sid}))
        gsend({'realtimeInput':{'text':'התחל את השיחה'}})
        try:
            while not st['stop']:
                m=ws.receive()
                if m is None: break
                if isinstance(m,(bytes,bytearray)): gsend({'realtimeInput':{'audio':{'data':base64.b64encode(bytes(m)).decode(),'mimeType':'audio/pcm;rate=16000'}}})
        finally:
            st['stop']=True; LATEST.update(status='ended')
            try: g.close()
            except Exception: pass
    @app.route('/api/phone/latest')
    def latest(): return jsonify(LATEST)
    @sock.route('/twilio/ws')
    def tw_ws(ws):
        sid=uuid.uuid4().hex[:8]; SES[sid]=brain.new_session()
        for x in list(LV.values()): x.close()
        LV.clear(); LV[sid]=live.Live(sid); LATEST.update(sid=sid,status='connecting',t=time.time())
        st={'stream':None,'stop':False,'gem':None,'rs_in':None,'rs_out':None}
        lock=threading.Lock()
        def tw_send(o):
            with lock:
                try: ws.send(json.dumps(o))
                except Exception: st['stop']=True
        def gem_send(o):
            try: st['gem'].send(json.dumps(o))
            except Exception as e: print('gem send fail',e,flush=True); st['stop']=True
        def gem_reader():
            g=st['gem']
            while not st['stop']:
                try: raw=g.recv()
                except Exception as e: print('gem recv end',e,flush=True); break
                if not raw: break
                m=json.loads(raw)
                sc=m.get('serverContent') or {}
                if sc.get('interrupted') and st['stream']: tw_send({'event':'clear','streamSid':st['stream']})
                for p in (sc.get('modelTurn') or {}).get('parts',[]):
                    d=(p.get('inlineData') or {}).get('data')
                    if d and st['stream']:
                        pcm=base64.b64decode(d); pcm8,st['rs_out']=audioop.ratecv(pcm,2,1,24000,8000,st['rs_out'])
                        u=audioop.lin2ulaw(pcm8,2)
                        for i in range(0,len(u),640): tw_send({'event':'media','streamSid':st['stream'],'media':{'payload':base64.b64encode(u[i:i+640]).decode()}})
                if sc.get('inputTranscription'): print('USER:',sc['inputTranscription'].get('text'),flush=True)
                if sc.get('outputTranscription'): print('BOT:',sc['outputTranscription'].get('text'),flush=True)
                tc=m.get('toolCall')
                if tc:
                    resp=[]
                    for fc in tc.get('functionCalls',[]):
                        with app.test_client() as c:
                            r=c.post('/api/rt/tool',json={'sid':sid,'name':fc['name'],'args':fc.get('args') or {}}).get_json()
                        print('TOOL',fc['name'],fc.get('args'),'->',r,flush=True)
                        resp.append({'id':fc['id'],'name':fc['name'],'response':r})
                    gem_send({'toolResponse':{'functionResponses':resp}})
            st['stop']=True
        try:
            while True:
                raw=ws.receive()
                if raw is None: break
                m=json.loads(raw); ev=m.get('event')
                if ev=='start':
                    st['stream']=m['start']['streamSid']; LATEST.update(status='in-call')
                    g=websocket.create_connection('wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key='+GEM_KEY,timeout=30)
                    g.settimeout(None); st['gem']=g
                    gem_send({'setup':{'model':'models/'+GEM_MODEL,'generationConfig':{'responseModalities':['AUDIO'],'speechConfig':{'voiceConfig':{'prebuiltVoiceConfig':{'voiceName':'Charon'}}}},
                        'systemInstruction':{'parts':[{'text':instr+'\nזו שיחת טלפון. התחל מיד בברכה קצרה.'}]},
                        'tools':[{'functionDeclarations':decls(tools)}],'inputAudioTranscription':{},'outputAudioTranscription':{}}})
                    print('setup resp',str(g.recv())[:120],flush=True)
                    threading.Thread(target=gem_reader,daemon=True).start()
                    gem_send({'realtimeInput':{'text':'התחל את השיחה'}})
                elif ev=='media' and st['gem']:
                    u=base64.b64decode(m['media']['payload']); pcm=audioop.ulaw2lin(u,2)
                    pcm16,st['rs_in']=audioop.ratecv(pcm,2,1,8000,16000,st['rs_in'])
                    gem_send({'realtimeInput':{'audio':{'data':base64.b64encode(pcm16).decode(),'mimeType':'audio/pcm;rate=16000'}}})
                elif ev=='stop': break
        finally:
            st['stop']=True; LATEST.update(status='ended')
            try: st['gem'].close()
            except Exception: pass
